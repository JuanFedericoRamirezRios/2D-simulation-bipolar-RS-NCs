/****************
 * 2D simulation bipolar Resistive Switching. We assume NCs like fixed oxigen vacancies.
 * If you use this software please cite: https://doi.org/10.3390/nano13142124
 * It is compiled by ROOT V6.28
 * Install ROOT on linux or windows using: https://root.cern/install/
 *
 * GPL-3.0 license
 *
 * **************/
#include "TF1.h"
#include "TH2F.h"
#include "Math/WrappedTF1.h"
#include "Math/BrentRootFinder.h"
#include "TMath.h"
#include "TRandom.h"
#include "stdio.h"
#include "TGFrame.h"
#include <iomanip>
#include "iostream"
// #include <filesystem>
#include <sstream>
#include "fstream"
// #include <unistd.h>
#include "TGSlider.h"
#include "TGNumberEntry.h"
#include "TGButton.h"
#include "TGTextEntry.h"
#include "TCanvas.h"
#include "TGLabel.h"
#include "TGFrame.h"
#include "TRootCanvas.h"
#include "TStyle.h"
#include "TRandom1.h"
#include "TGraph.h"
#include "TMultiGraph.h"
#include "TMatrixD.h"
#include "TVectorD.h"
#include "TDecompLU.h"
#include "TApplication.h"
#include "TSystemDirectory.h"

using namespace std;

class MAIN_FRAME : public TGMainFrame
{
public:
    MAIN_FRAME();

    void Init();
    void DrawData();
    void GenerRecomVo(Double_t Vl, Double_t Vr, Double_t stepTime, Double_t gamma, Double_t gammaDrift); //[gamma] = cm*e, [gammaDrift] = cm
    void SaveVos(Double_t Vl);
    void JouleHeatOutDataOutVoCs(Double_t Vl);
    void CalcCurrent(Double_t Vl, Double_t Vr);
    void Forming(Double_t initVl, Double_t endVl, Double_t step);
    void SetProcess(Double_t initVl, Double_t endVl, Double_t step);
    void ResetProcess(Double_t initVl, Double_t endVl, Double_t step);
    void SweepProcess(Double_t initVl, Double_t endVl, Double_t step);
    void Simulate();
    void DrawLastSimulation();
    void CloseWindow();

    TCanvas *NsVsVcanv;
    TCanvas *IvsVcanv;

    Bool_t openApp;

    Double_t N_LRS;    // u.a.
    Double_t N_HRS;    // u.a.
    Double_t Nfresh;   // u.a.
    Double_t Vforming; // V
    Double_t Vreset;   // V
    Double_t Vset;     // V
    Double_t Khrs;     // u.a.
    Double_t Klrs;     // u.a. * cm3

    Double_t gammaSET;
    Double_t gammaRESET;
    Double_t phiDrift;
    Double_t complIforming; // Amp
    Double_t complIreset;   // Amp
    Double_t complIset;     // Amp
    Double_t a;             // cm
    Double_t A;             // cm2

    Double_t numVoIni;
    Double_t stepTime0; // sec
    Double_t Eoe;       // eV
    Double_t Eom;       // eV
    Double_t Lo;        // const. lattice a: [Lo] = a.
    Double_t beta0;
    Double_t Rth; // K/W
    Double_t Ao;  // cm

    Double_t cycles;
    Double_t Nc; // 1/cm3
    Double_t u;  // cm2/(V sec)
    Double_t epsilon;
    Double_t phit; // V
                   //    Double_t Easclc; // eV . Ea = phit.

    Double_t L; // cm
    Int_t rows;
    Int_t columns;

    Double_t sample[1000][1000][11]; //[][][0]: If Vo exist = 1, If Vo no exist = 0.
                                     //[][][1]: V homogeneous
                                     //[][][2]: fn
                                     //[][][3]: Feq
                                     //[][][4]: x position
                                     //[][][5]: y position
                                     //[][][6]: RiL_n
                                     //[][][7]: RoL_n
                                     //[][][8]: RiR_n
                                     //[][][9]: RoR_n
                                     //[][][10]: Fixed vacancies: 1 or 0

    Double_t copySample[1000][1000];
    Double_t bestSample[1000][1000];

    Double_t gap, T, I;        //[I] = Amp
    Double_t minIexp = 1.0;    // Amp
    Double_t OneOverTo = 1E13; // Hz

    TGTextEntry *expTextEntry;
    TGTextEntry *structureTextEntry;
    TGTextEntry *outputTextEntry;
    TGTextButton *simulateButton;
    TGTextButton *drawButton;

    Double_t q = 1.0;     // e
    Double_t k = 8.62E-5; // eV/K

    // Double_t Ro = 1E12;                       // Hz
    // Double_t EcMinusEvoEmpty = 1.83;          // eV
    // Double_t EcMinusEvoFull = 1.97;           // eV
    // Double_t Eg = 5.68;                       // eV
    // Double_t EvoEmpty = Eg - EcMinusEvoEmpty; // eV. If Ev = 0eV.
    // Double_t EvoFull = Eg - EcMinusEvoFull;   // eV. If Ev = 0eV.
    // Double_t El_f = -1.9;                     // eV
    // Double_t Er_f = -1.9;                     // eV
//    Double_t hbar = 6.57E-16;                 // eV s
//    Double_t m = 0.1 * (5.67E-16);            // eV s2/ cm2
//    Double_t R0_tunnelNlr = 1E14;             // Hz

    Double_t Tr = 297.0; // ºK

    Int_t sumVo, sumVoIncVoFix;
    Double_t v, F_H, t;
    Double_t Fhrs, Flrs;
    Double_t Jhrs, Jlrs, Jpf, Jsclc; // e/s-cm2

    ofstream outFile;

    Double_t e = 1.6E-19;      // Coulombs
    Double_t Ns;               // u.a.
    Double_t epsilon0 = 553E3; // e/(V cm)

    Int_t numProcess = 0;
    Bool_t achievCurrCompl;

    TCanvas *printCanvas;
    TString nameMatrix;
    Int_t contMatrixVo;
};
class CONTROLS_SCIENTIFIC : public TGVerticalFrame
{
public:
    CONTROLS_SCIENTIFIC(TGFrame *father, TString name, TString units, Double_t &value1);

    void DoMaxFac();
    void DoFac();
    void MoveFacSlider(Int_t param);
    void DoMinFac();
    void DoMaxExp();
    void DoExp();
    void MoveExpSlider(Int_t param);
    void DoMinExp();

    Double_t *value, fac, minFac, maxFac;
    Int_t exp, minExp, maxExp;
    TString name, units;

    TGLabel *valueLabel;

    TGNumberEntry *maxFacNumberEntry, *facNumberEntry, *minFacNumberEntry;
    TGVSlider *facSlider;

    TGNumberEntry *maxExpNumberEntry, *expNumberEntry, *minExpNumberEntry;
    TGVSlider *expSlider;
};
class CONTROLS_VALUE : public TGVerticalFrame
{
public:
    CONTROLS_VALUE(TGFrame *father, TString name, TString units, Double_t &value1);

    Double_t MinDoubleValue(Double_t doubleValue);
    Double_t MaxDoubleValue(Double_t doubleValue);
    void DoMax();
    void DoValue();
    void MoveSlider(Int_t param);
    void DoMin();

    Double_t *value, min, max;
    TString name, units;

    TGLabel *valueLabel;

    TGNumberEntry *maxNumberEntry, *valueNumberEntry, *minNumberEntry;
    TGVSlider *valueSlider;
};
void GUAN2012HU2017_2D()
{
    new MAIN_FRAME();
}
MAIN_FRAME::MAIN_FRAME() : TGMainFrame(gClient->GetRoot()) {
    cout << endl; 
    
    NsVsVcanv = new TCanvas("NsVsVcanv", "Ns(a.u) Vs V(V)", 100, 600, 300, 250);
    ((TRootCanvas *)NsVsVcanv->GetCanvasImp())->DontCallClose();
    IvsVcanv = new TCanvas("IvsVcanv", "I(A) Vs V(V)", 600, 600, 300, 250);
    ((TRootCanvas *)IvsVcanv->GetCanvasImp())->DontCallClose();

    openApp = true;
    DrawData();

    N_LRS = 0.2;     // u.a.
    // N_HRS = -0.7;   // u.a.
    N_HRS = -1.0;   // u.a.
    // Nfresh = -1.4;  // u.a.
    Nfresh = -2.0;  // u.a.
    // Vforming = 4.3; // V
    Vforming = 5.1; // V
    // Vreset = -4.0;   // V
    Vreset = -3.8;   // V
    // Vset = 3.2;      // V
    Vset = 3.8;      // V
    // Khrs = 8.0E-23;  // u.a.
    Khrs = 8.0E-20;  // u.a.
    // Klrs = 3.0E-35;  // u.a. * cm3
    Klrs = 1.0E-30;  // u.a. * cm3

    gammaSET = 4.6;
    gammaRESET = 0.4;
    phiDrift = 8.0;
    // complIforming = 8.0e-7; // Amp
    complIforming = 0.0001; // Amp
    // complIreset = 8.0e-7;   // Amp
    complIreset = 0.0001;   // Amp
    // complIset = 8.0e-7;     // Amp
    complIset = 0.0001;     // Amp
    a = 0.5E-7;             // cm
    A = 10.0E-3;            // cm2

    // numVoIni = 0.0;
    numVoIni = 0.0;
    stepTime0 = 5.0E-6; // sec
    // Eoe = 1.1;          // eV
    Eoe = 1.0;          // eV
    // Eom = 1.1;          // eV
    Eom = 1.0;          // eV
    Lo = 6.3;           // const. lattice a: [Lo] = a.
    beta0 = 6.0E6;
    // Rth = 8.0E7;  // K/W
    Rth = 9.0E5;  // K/W
    Ao = 0.33E-7; // cm

    cycles = 1.0;
    Nc = 2.86E19; // 1/cm3  from Park 2020: Electrical Defect State Distribution in Single Crystal ZnO Schottky Barrier Diodes
    u = 1450.0;   // cm2/(V sec)
    epsilon = 11.9;
    phit = 0.1; // V
                //    Easclc = 0.5; // eV . Ea = phit.

    /*********************************GUI************************************/

    TGLayoutHints *expandHints = new TGLayoutHints(kLHintsExpandX | kLHintsExpandY, 1, 1, 1, 1);
    TGLayoutHints *topHints = new TGLayoutHints(kLHintsExpandX | kLHintsTop, 1, 1, 1, 1);
    TGLayoutHints *centerHints = new TGLayoutHints(kLHintsExpandX | kLHintsCenterY, 1, 1, 1, 1);
    TGLayoutHints *bottomHints = new TGLayoutHints(kLHintsExpandX | kLHintsBottom, 1, 1, 1, 1);

    /*************************Model controls******************************/

    TGHorizontalFrame *hFrame1 = new TGHorizontalFrame(this, 0, 0, 0);
    AddFrame(hFrame1, expandHints);

    CONTROLS_VALUE *N_LRSControls = new CONTROLS_VALUE(hFrame1, "N_LRS", "au", N_LRS);
    hFrame1->AddFrame(N_LRSControls, expandHints);

    CONTROLS_VALUE *N_HRSControls = new CONTROLS_VALUE(hFrame1, "N_HRS", "au", N_HRS);
    hFrame1->AddFrame(N_HRSControls, expandHints);

    CONTROLS_VALUE *NfreshControls = new CONTROLS_VALUE(hFrame1, "Nfresh", "au", Nfresh);
    hFrame1->AddFrame(NfreshControls, expandHints);

    CONTROLS_VALUE *VformingControls = new CONTROLS_VALUE(hFrame1, "Vforming", "V", Vforming);
    hFrame1->AddFrame(VformingControls, expandHints);

    CONTROLS_VALUE *VresetControls = new CONTROLS_VALUE(hFrame1, "Vreset", "V", Vreset);
    hFrame1->AddFrame(VresetControls, expandHints);

    CONTROLS_VALUE *VsetControls = new CONTROLS_VALUE(hFrame1, "Vset", "V", Vset);
    hFrame1->AddFrame(VsetControls, expandHints);

    CONTROLS_SCIENTIFIC *KpfControls = new CONTROLS_SCIENTIFIC(hFrame1, "K_HRS", "au", Khrs);
    hFrame1->AddFrame(KpfControls, expandHints);

    CONTROLS_SCIENTIFIC *KsclcControls = new CONTROLS_SCIENTIFIC(hFrame1, "K_LRS", "au-cm3", Klrs);
    hFrame1->AddFrame(KsclcControls, expandHints);

    /********************************************************************************/

    TGHorizontalFrame *hFrame2 = new TGHorizontalFrame(this, 0, 0, 0);
    AddFrame(hFrame2, expandHints);

    //    Double_t gammaSET, minGammaSET, maxGammaSET;
    CONTROLS_VALUE *gammaSETcontrols = new CONTROLS_VALUE(hFrame2, "gamSET", "", gammaSET);
    hFrame2->AddFrame(gammaSETcontrols, expandHints);

    //    Double_t gammaRESET, minGammaRESET, maxGammaRESET;
    CONTROLS_VALUE *gammaRESETcontrols = new CONTROLS_VALUE(hFrame2, "gamRESET", "", gammaRESET);
    hFrame2->AddFrame(gammaRESETcontrols, expandHints);

    //     Double_t phiDrift, minPhiDrift, maxPhiDrift;
    CONTROLS_VALUE *phiDriftControls = new CONTROLS_VALUE(hFrame2, "phiDrift", "", phiDrift);
    hFrame2->AddFrame(phiDriftControls, expandHints);

    // Double_t complIforming, complIformingFac, minComplIformingFac, maxComplIformingFac; Int_t complIformingExp, minComplIformingExp, maxComplIformingExp; // Amp
    CONTROLS_SCIENTIFIC *complIformingControls = new CONTROLS_SCIENTIFIC(hFrame2, "IcomplForming", "A", complIforming);
    hFrame2->AddFrame(complIformingControls, expandHints);

    // Double_t complIreset, complIresetFac, minComplIresetFac, maxComplIresetFac; Int_t complIresetExp, minComplIresetExp, maxComplIresetExp; // Amp
    CONTROLS_SCIENTIFIC *complIresetControls = new CONTROLS_SCIENTIFIC(hFrame2, "IcomplReset", "A", complIreset);
    hFrame2->AddFrame(complIresetControls, expandHints);

    // Double_t complIset, complIsetFac, minComplIsetFac, maxComplIsetFac; Int_t complIsetExp, minComplIsetExp, maxComplIsetExp; // Amp
    CONTROLS_SCIENTIFIC *complIsetControls = new CONTROLS_SCIENTIFIC(hFrame2, "IcomplSet", "A", complIset);
    hFrame2->AddFrame(complIsetControls, expandHints);

    // 	Double_t a, min_a, max_a; // cm
    CONTROLS_VALUE *aControls = new CONTROLS_VALUE(hFrame2, "a", "cm", a);
    hFrame2->AddFrame(aControls, expandHints);

    // 	Double_t A, Afac, minAfac, maxAfac; Int_t Aexp, minAexp, maxAexp; // cm2
    CONTROLS_SCIENTIFIC *Acontrols = new CONTROLS_SCIENTIFIC(hFrame2, "A", "cm2", A);
    hFrame2->AddFrame(Acontrols, expandHints);

    /********************************************************************************/

    TGHorizontalFrame *hFrame3 = new TGHorizontalFrame(this, 0, 0, 0);
    AddFrame(hFrame3, expandHints);

    // 	Double_t numVoIni, minNumVoIni, maxNumVoIni;
    CONTROLS_VALUE *numVoIniControls = new CONTROLS_VALUE(hFrame3, "VoIni", "", numVoIni);
    hFrame3->AddFrame(numVoIniControls, expandHints);

    //     Double_t stepTime0, stepTime0Fac, minStepTime0Fac, maxStepTime0Fac; Int_t stepTime0Exp, minStepTime0Exp, maxStepTime0Exp; // sec
    CONTROLS_SCIENTIFIC *stepTime0Controls = new CONTROLS_SCIENTIFIC(hFrame3, "t_ini", "s", stepTime0);
    hFrame3->AddFrame(stepTime0Controls, expandHints);

    //     Double_t Eoe, minEoe, maxEoe; // eV
    CONTROLS_VALUE *EoeControls = new CONTROLS_VALUE(hFrame3, "E_Oe", "eV", Eoe);
    hFrame3->AddFrame(EoeControls, expandHints);

    //     Double_t Eom, minEom, maxEom; // eV
    CONTROLS_VALUE *EomControls = new CONTROLS_VALUE(hFrame3, "E_Om", "eV", Eom);
    hFrame3->AddFrame(EomControls, expandHints);

    // Double_t Lo, minLo, maxLo; //const. lattice a: [Lo] = a.
    CONTROLS_VALUE *LoControls = new CONTROLS_VALUE(hFrame3, "L_O", "a", Lo);
    hFrame3->AddFrame(LoControls, expandHints);

    //     Double_t beta0, beta0Fac, minBeta0Fac, maxBeta0Fac; Int_t beta0Exp, minBeta0Exp, maxBeta0Exp;
    CONTROLS_SCIENTIFIC *beta0Controls = new CONTROLS_SCIENTIFIC(hFrame3, "Bo", "", beta0);
    hFrame3->AddFrame(beta0Controls, expandHints);

    //     Double_t Rth, RthFac, minRthFac, maxRthFac; Int_t RthExp, minRthExp, maxRthExp; // K/W
    CONTROLS_SCIENTIFIC *RthControls = new CONTROLS_SCIENTIFIC(hFrame3, "Rth", "K/W", Rth);
    hFrame3->AddFrame(RthControls, expandHints);

    //     Double_t Ao, minAo, maxAo; // cm
    CONTROLS_VALUE *AoControls = new CONTROLS_VALUE(hFrame3, "Ao", "cm", Ao);
    hFrame3->AddFrame(AoControls, expandHints);

    /********************************************************************************/

    TGHorizontalFrame *hFrame4 = new TGHorizontalFrame(this, 0, 0, 0);
    AddFrame(hFrame4, expandHints);

    //     Double_t cycles, minCycles, maxCyles;
    CONTROLS_VALUE *cyclesControls = new CONTROLS_VALUE(hFrame4, "cycles", "", cycles);
    hFrame4->AddFrame(cyclesControls, expandHints);

    //     Double_t Nc, NcFac, minNcFac, maxNcFac; Int_t NcExp, minNcExp, maxNcExp; // 1/cm3
    CONTROLS_SCIENTIFIC *NcControls = new CONTROLS_SCIENTIFIC(hFrame4, "Nc", "/cm3", Nc);
    hFrame4->AddFrame(NcControls, expandHints);

    //     Double_t u, min_u, max_u; // cm2/(V sec)
    CONTROLS_VALUE *uControls = new CONTROLS_VALUE(hFrame4, "u", "cm2/V-s", u);
    hFrame4->AddFrame(uControls, expandHints);

    //     Double_t epsilon, minEpsilon, maxEpsilon;
    CONTROLS_VALUE *epsilonControls = new CONTROLS_VALUE(hFrame4, "perm", "", epsilon);
    hFrame4->AddFrame(epsilonControls, expandHints);

    //     Double_t phit, minPhit, maxPhit; // V
    CONTROLS_VALUE *phitControls = new CONTROLS_VALUE(hFrame4, "phit", "V", phit);
    hFrame4->AddFrame(phitControls, expandHints);

    TGVerticalFrame *emptyFrame3 = new TGVerticalFrame(hFrame4);
    hFrame4->AddFrame(emptyFrame3, expandHints);

    TGVerticalFrame *vFrame1 = new TGVerticalFrame(hFrame4);
    hFrame4->AddFrame(vFrame1, expandHints);

    TGHorizontalFrame *hFrame5 = new TGHorizontalFrame(vFrame1);
    vFrame1->AddFrame(hFrame5, centerHints);
    TGLabel *expLabel = new TGLabel(hFrame5, "Experim:");
    hFrame5->AddFrame(expLabel, expandHints);
    expTextEntry = new TGTextEntry(hFrame5, "K-63-RT_exp_corrct.dat");
    hFrame5->AddFrame(expTextEntry, expandHints);

    TGHorizontalFrame *hFrame6 = new TGHorizontalFrame(vFrame1);
    vFrame1->AddFrame(hFrame6, centerHints);
    TGLabel *structureLabel = new TGLabel(hFrame6, "Structure:");
    hFrame6->AddFrame(structureLabel, expandHints);
    structureTextEntry = new TGTextEntry(hFrame6, "K-63-RT-shift-VoInter.txt");
    hFrame6->AddFrame(structureTextEntry, expandHints);

    TGHorizontalFrame *hFrame7 = new TGHorizontalFrame(vFrame1);
    vFrame1->AddFrame(hFrame7, centerHints);
    TGLabel *outputLabel = new TGLabel(hFrame7, "Out file:");
    hFrame7->AddFrame(outputLabel, expandHints);
    outputTextEntry = new TGTextEntry(hFrame7, "outFile.dat");
    hFrame7->AddFrame(outputTextEntry, expandHints);

    TGVerticalFrame *vFrame2 = new TGVerticalFrame(hFrame4);
    hFrame4->AddFrame(vFrame2, expandHints);

    simulateButton = new TGTextButton(vFrame2, "SIMULATE");
    vFrame2->AddFrame(simulateButton, centerHints);
    simulateButton->Connect("Clicked()", "MAIN_FRAME", this, "Simulate()");

    drawButton = new TGTextButton(vFrame2, "DRAW LAST SIMULATION");
    vFrame2->AddFrame(drawButton, centerHints);
    drawButton->Connect("Clicked()", "MAIN_FRAME", this, "DrawLastSimulation()");

    /********************************************************************************/
    printCanvas = new TCanvas("printCanvas", "Oxygen vacancy configuration", 100, 580, 250, 250);

    gStyle->SetPalette(kRainBow); // Style of the colour for the hystograms: https://root.cern/doc/master/classTColor.html#C06
    gStyle->SetOptStat(0);        // No see the error tables
    gStyle->SetTitleFontSize(0.1);

    Init();

    ((TRootCanvas *)printCanvas->GetCanvasImp())->DontCallClose();
    ((TRootCanvas *)printCanvas->GetCanvasImp())->UnmapWindow(); // Hide printCanvas
    MapSubwindows();

    Resize(1400, 500);
    SetWMPosition(100, 50);

    MapWindow();

    return;
}
void MAIN_FRAME::Init()
{
    Char_t arrChar[1000];
    ifstream inputLayers(structureTextEntry->GetText());

    Int_t rowLine = 0;
    while (!inputLayers.eof())
    {
        inputLayers.getline(arrChar, 1000);
        if (arrChar[0] == '\0')
            continue;
        for (Int_t n = 0; n < 1000; n++)
        {
            if (arrChar[n] == '\0')
            {
                columns = n;
                rowLine++;
                break;
            }
            else
            {
                if (arrChar[n] == '2')
                {
                    sample[rowLine][n][0] = 1.0;
                    sample[rowLine][n][10] = 1.0;
                }
                else if(arrChar[n] == '1') 
                {
                    sample[rowLine][n][0] = 1.0;
                    sample[rowLine][n][10] = 0.0;
                }
                else
                {
                    sample[rowLine][n][0] = 0.0;
                    sample[rowLine][n][10] = 0.0;
                }
            }
        }
    }
    inputLayers.close();

    rows = rowLine;

    L = columns * a;

    cout << "rows = " << rows << ", columns = " << columns << ", L = " << L << "cm" << endl;

    TRandom1 *randObj = new TRandom1();
    Int_t rndRow;
    Int_t rndCol;
    Int_t conVo = 0;
    while (conVo < (numVoIni - 0.1))
    {
        rndRow = (Int_t)rows * randObj->Rndm();
        rndCol = (Int_t)columns * randObj->Rndm();
        if (sample[rndRow][rndCol][10] < 0.5 && sample[rndRow][rndCol][0] < 0.5)
        {
            sample[rndRow][rndCol][0] = 1.0;
            conVo++;
        }
    }

    for (Int_t n = 0; n < rows; n++)
    {
        for (Int_t m = 0; m < columns; m++)
        {
            sample[n][m][4] = m * a;
            // sample[n][m][5] = n * a;
        }
    }
    numProcess = 0;
    I = 0.0;
    Ns = 0.0;
    T = 297.0;

    contMatrixVo = 1;
}
void MAIN_FRAME::DrawData()
{

    Char_t chars[10000];
    TString numText;
    Double_t V, I;
    cout << "Drawing the experimental data" << endl;

    TGraph *IvsVgraphExp = new TGraph();
    TMultiGraph *IvsVmultiGraph = new TMultiGraph();
    IvsVgraphExp->SetLineColor(2);
    IvsVgraphExp->SetLineWidth(2);
    IvsVmultiGraph->Add(IvsVgraphExp);

    // ifstream inputExperiment;
    if (openApp) {
        //inputExperiment.open("0data.dat");
        IvsVgraphExp->SetPoint(0, 0, 1.0E-12);
        IvsVmultiGraph->SetMinimum(1.0E-12); // Minimum of axis y
        IvsVcanv->Clear();
        IvsVcanv->SetGrid();
        IvsVcanv->SetLogy(); // Semilog graph.
        IvsVcanv->cd();
        IvsVmultiGraph->Draw("A");
        IvsVcanv->Modified();
        IvsVcanv->Update();
        return;
    }       
        
    ifstream inputExperiment;
    inputExperiment.open(expTextEntry->GetText());
    Int_t numExpData = 0;
    while (!inputExperiment.eof())
    {
        inputExperiment.getline(chars, 10000);
        if (chars[0] == '\0')
            continue;
        numText = "";
        for (Int_t n = 0; n < 10000; n++)
        {
            if ((chars[n] == '\t') || (chars[n] == ' '))
            {
                if (!numText.IsFloat())
                    break;
                V = numText.Atof();
                numText = "";
            }
            else if (chars[n] == '\0')
            {
                if (!numText.IsFloat())
                    break;
                I = numText.Atof();
                if (I < minIexp)
                    minIexp = I;
                IvsVgraphExp->SetPoint(numExpData, V, I);
                numExpData++;
                break;
            }
            else
            {
                numText += chars[n];
            }
        }
    }
    inputExperiment.close();

    cout << "Drawing the calculated data" << endl; // Reading and drawing experimental data.

    ifstream inputSimulation(outputTextEntry->GetText());
    Int_t numSimData = 0, column;
    TGraph *IvsVgraphSim = new TGraph();
    TGraph *NsVsVgraphSim = new TGraph();
    while (!inputSimulation.eof())
    {
        inputSimulation.getline(chars, 10000);
        if (chars[0] == '\0')
            continue;
        numText = "";
        column = 1;
        for (Int_t n = 0; n < 10000; n++)
        {
            if ((chars[n] == '\t') || (chars[n] == ' '))
            {

                if (!numText.IsFloat())
                    break;

                if (column == 1)
                {
                    V = numText.Atof();
                }
                else if (column == 2)
                {
                    Ns = numText.Atof();
                }
                else if (column == 3)
                {
                    I = numText.Atof();
                    IvsVgraphSim->SetPoint(numSimData, V, I);
                    NsVsVgraphSim->SetPoint(numSimData, V, Ns);
                    numSimData++;
                    break;
                }
                numText = "";

                column++;
            }
            else if (chars[n] == '\0')
            {
                // When you need the last column.
            }
            else
            {
                numText += chars[n];
            }
        }
    }
    inputSimulation.close();

    IvsVgraphSim->SetLineColor(4);
    IvsVgraphSim->SetLineWidth(2);
    IvsVmultiGraph->Add(IvsVgraphSim);
    IvsVmultiGraph->SetMinimum(minIexp); // Minimum of axis y
    IvsVcanv->Clear();
    IvsVcanv->SetGrid();
    IvsVcanv->SetLogy(); // Semilog graph.
    IvsVcanv->cd();
    IvsVmultiGraph->Draw("A");
    IvsVcanv->Modified();
    IvsVcanv->Update();

    TMultiGraph *NsVsVmultiGraph = new TMultiGraph();
    NsVsVgraphSim->SetLineColor(3);
    NsVsVgraphSim->SetLineWidth(2);
    NsVsVmultiGraph->Add(NsVsVgraphSim);
    NsVsVcanv->Clear();
    NsVsVcanv->SetGrid();
    NsVsVcanv->cd();
    NsVsVmultiGraph->Draw("A"); // Why do I must to use multigraph on Draw("A")?
    NsVsVcanv->Modified();
    NsVsVcanv->Update();
}
void MAIN_FRAME::GenerRecomVo(Double_t Vl, Double_t Vr, Double_t stepTime, Double_t gamma, Double_t phiDrift)
{
    t = stepTime;
    Double_t sumVoRow, sumRn;
    Double_t numVo;
    for (Int_t n = 0; n < rows; n++)
    {
        sumVoRow = 0.0;
        for (Int_t m = 0; m < columns; m++)
        {
            sumVoRow += sample[n][m][0];
        }
        for (Int_t m = 0; m < columns; m++)
        {
            sample[n][m][3] = TMath::Abs(Vl - Vr) / (L - a * sumVoRow); // Feq
        }
    }

    F_H = -(Vr - Vl) / L;
    TRandom1 *randObj = new TRandom1();
    Double_t Pg, u, beta, P0_r, Pr, randValue;

    v = a * OneOverTo * TMath::Exp(-Eom / (k * T)) * TMath::SinH(q * phiDrift * a * (-F_H) / (k * T));

    for (Int_t n = 0; n < rows; n++)
    {
        for (Int_t m = 0; m < columns; m++)
        {
            Pg = stepTime * OneOverTo * TMath::Exp(-(Eoe - q * gamma * a * sample[n][m][3]) / (k * Tr));


            if (sample[n][m][4] <= (v * stepTime))
            {
                u = 1.0;
            }
            else if (((v * stepTime) < sample[n][m][4]) && (sample[n][m][4] <= (v * stepTime + a)))
            {
                u = 0.3;
            }
            else if (((v * stepTime + a) < sample[n][m][4]) && (sample[n][m][4] <= (v * stepTime + 3 * a)))
            {
                u = 0.1;
            }
            else if ((v * stepTime + 3 * a) < sample[n][m][4])
            {
                u = 0.0;
            }
            else
            {
                cout << "Warning: interval for x position no valid for u function" << endl;
            }

            beta = beta0 * TMath::Exp(-TMath::Abs(v) * stepTime / (Lo * a)) * u;
            P0_r = stepTime * OneOverTo * TMath::Exp(-Eoe / (k * T));
            Pr = beta * P0_r;
            randValue = randObj->Rndm();
            if (sample[n][m][10] < 0.5)
            { // If is not a fixed vacancies (nanocrystals)
                if (sample[n][m][0] < 0.5)
                { // Is not a trap?
                    if (Pg > randValue)
                    {
                        sample[n][m][0] = 1.0;
                    }
                }
                else
                { // Is a trap?
                    if (Pr > randValue)
                    {
                        sample[n][m][0] = 0.0;
                    }
                }
            }
        }
    }

    sumVo = 0;
    sumVoIncVoFix = 0;

    sumRn = 0.0;
    for (Int_t n = 0; n < rows; n++)
    {
        numVo = 0.0;
        for (Int_t m = 0; m < columns; m++)
        {
            if (sample[n][m][0] > 0.5)
            {
                numVo++;
                sumVoIncVoFix++; // It includes Vo fixed.
            }
            if ((sample[n][m][10] < 0.5) && (sample[n][m][0] > 0.5)) // It does not include Vo fixed.
                sumVo++; 
        }
        sumRn += TMath::Exp((a * numVo - L) / Ao);
    }
    Ns = TMath::Log(sumRn) / rows;
}
void MAIN_FRAME::SaveVos(Double_t Vl)
{
    ostringstream oString;
    oString << setprecision(3) << (Vl);

    nameMatrix = "configurations/";
    Int_t dig = TMath::Log10(contMatrixVo);
    for (Int_t n = 0; n <= (6 - dig); n++)
        nameMatrix += "0"; // Add zeros for alphabet order.
    nameMatrix += contMatrixVo;
    nameMatrix += " ";
    nameMatrix += "proc";
    nameMatrix += numProcess;
    nameMatrix += " ";
    nameMatrix += oString.str(); // oString is the voltage.
    nameMatrix += "V";
    nameMatrix += ".txt";

    ofstream outVacanciesConfig;
    outVacanciesConfig.open(nameMatrix);

    for (Int_t y = 0; y < rows; y++)
    {
        for (Int_t x = 0; x < columns; x++)
        {
            if (sample[(rows - 1) - y][x][10] > 0.5)
                outVacanciesConfig << "2"; // If it is a fixed vacancie.
            else
            {
                outVacanciesConfig << sample[(rows - 1) - y][x][0]; // else it is a 1.0->Vo or 0.0->W/o Vo
            }
        }
        outVacanciesConfig << endl;
    }
    outVacanciesConfig.close();

    contMatrixVo++; 
}
void MAIN_FRAME::JouleHeatOutDataOutVoCs(Double_t Vl)
{
    T = Tr + TMath::Abs(Vl * I) * Rth;
    // outFile << "V (V) Ns (a.u.) I (A) T (K) (sumVos w/o ncs) (sumVos with ncs) F_H(V/cm) v (cm/s) t (s) v*t (*a) Ipf (A) Isclc (A) Ipf*Khrs (A) Isclc*Klrs (A*cm3) Fhrs Flrs Ihrs (A) Ilrs (A) (num procs)"
    outFile << Vl << "\t" << Ns << "\t" << I << "\t" << T << "\t" << sumVo << "\t" << sumVoIncVoFix << "\t" << F_H << "\t" << v << "\t" << t << "\t" << v*t/a << "\t" << Jpf*e*A << "\t" << Jsclc*e*A << "\t" << Jpf*e*A*Khrs << "\t" << Jsclc*e*A*Klrs << "\t" << Fhrs << "\t" << Flrs << "\t" << Jhrs*e*A << "\t" << Jlrs*e*A << "\t" << numProcess << endl;
    if ((numProcess == ((Int_t)cycles)) || numProcess == 0) // Only shows the zero cycle and last cycle.
    {
        SaveVos(Vl); 
    }
}
void MAIN_FRAME::CalcCurrent(Double_t Vl, Double_t Vr)
{
    Double_t beta = TMath::Sqrt(q * q * q / (TMath::Pi() * epsilon * epsilon0));
    Double_t V = TMath::Abs(Vl - Vr);

    Jpf = q * u * Nc * V / L * TMath::Exp((beta * TMath::Sqrt(V / L) - q * phit) / (k * Tr)); // e/s-cm2
    Jsclc = 9 / 8 * u * epsilon * epsilon0 * TMath::Power(V, 2.0) / (L * L * L) * Nc / (Ns - Nfresh) * TMath::Exp(-phit / (k * T)) * TMath::Exp(0.891 / (k * T) * beta * TMath::Sqrt(V / L)); // e/s-cm2
    // Double_t Jhop = q * a * Nc * OneOverTo * TMath::Exp(q*a*V/(L * k * T)-phit/(k * T)); // e/s-cm2

    if (Ns <= Nfresh)
    {
        Jhrs = 0.0;
        Fhrs = 0.0;
    }
    else if ((Nfresh < Ns) && (Ns <= N_HRS))
    {
        Jhrs = (Ns - Nfresh) / (N_HRS - Nfresh) * Khrs * Jpf;
        Fhrs = (Ns - Nfresh) / (N_HRS - Nfresh);
    }
    else if ((N_HRS < Ns) && (Ns <= N_LRS))
    {
        Jhrs = (N_LRS - Ns) / (N_LRS - N_HRS) * Khrs * Jpf;
        Fhrs = (N_LRS - Ns) / (N_LRS - N_HRS);
    }
    else if (N_LRS < Ns)
    {
        Jhrs = 0.0;
        Fhrs = 0.0;
    }

    if (Ns <= N_HRS)
    {
        Jlrs = 0.0;
        Flrs = 0.0;
    }
    else
    {
        Jlrs = (Ns - N_HRS) / (N_LRS - N_HRS) * Klrs * Jsclc;
        Flrs = (Ns - N_HRS) / (N_LRS - N_HRS);
    }

    I = (Jhrs + Jlrs) * e * A;
}

void MAIN_FRAME::Forming(Double_t initVl, Double_t endVl, Double_t step)
{
    achievCurrCompl = false;

    Double_t stepTime = stepTime0;

    for (Double_t Vl = initVl; Vl <= endVl; Vl += step)
    {
        if (achievCurrCompl)
        {
            GenerRecomVo(Vl, 0.0, stepTime, gammaSET, phiDrift);
            if (I > complIforming)
                I = complIforming;
            JouleHeatOutDataOutVoCs(Vl);
            continue;
        }
        for (Int_t n = 0; n < rows; n++)
        {
            for (Int_t m = 0; m < columns; m++)
            {
                copySample[n][m] = sample[n][m][0]; // Copy of status vacancies.
            }
        }
        GenerRecomVo(Vl, 0.0, stepTime0, gammaSET, phiDrift);
        CalcCurrent(Vl, 0.0);
        Int_t accuracy;
        if (I > complIforming)
        { // Amp
            achievCurrCompl = true;
            Double_t bestI = 10000.0 * complIforming; // Amp
            Bool_t achieveToleranceI = false;

            for (accuracy = 1; accuracy <= 100; accuracy++)
            {

                for (Int_t n = 0; n < rows; n++)
                {
                    for (Int_t m = 0; m < columns; m++)
                    {
                        sample[n][m][0] = copySample[n][m]; // Copy of status vacancies.
                    }
                }

                stepTime = stepTime0 / TMath::Power(1.1, accuracy);

                GenerRecomVo(Vl, 0.0, stepTime, gammaSET, phiDrift); // This changes sample[][][0].
                CalcCurrent(Vl, 0.0);

                if ((I > complIforming * 0.90) && (I < bestI))
                { // If I > 90%*currentCompliance and I < bestI
                    achieveToleranceI = true;
                    for (Int_t n = 0; n < rows; n++)
                    {
                        for (Int_t m = 0; m < columns; m++)
                        {
                            bestSample[n][m] = sample[n][m][0]; // Copy of status vacancies.
                        }
                    }
                    bestI = I;
                    // cout << accuracy << " " << I << "A " << stepTime << "s" << endl;
                }
            }
            if (achieveToleranceI)
            {
                for (Int_t n = 0; n < rows; n++)
                {
                    for (Int_t m = 0; m < columns; m++)
                    {
                        sample[n][m][0] = bestSample[n][m]; // Copy of status vacancies.
                    }
                }
                I = bestI;
            }
            else
            {
                for (Int_t n = 0; n < rows; n++)
                {
                    for (Int_t m = 0; m < columns; m++)
                    {
                        sample[n][m][0] = copySample[n][m]; // Copy of status vacancies.
                    }
                }
                I = complIforming;
            }
        }
        JouleHeatOutDataOutVoCs(Vl);
    }
}

void MAIN_FRAME::SetProcess(Double_t initVl, Double_t endVl, Double_t step)
{

    achievCurrCompl = false;

    Double_t stepTime = stepTime0;

    for (Double_t Vl = initVl; Vl < (endVl + step); Vl += step)
    {
        if (achievCurrCompl)
        {
            GenerRecomVo(Vl, 0.0, stepTime, gammaSET, phiDrift);
            if (I > complIset)
                I = complIset;
            JouleHeatOutDataOutVoCs(Vl);
            continue;
        }

        for (Int_t n = 0; n < rows; n++)
        {
            for (Int_t m = 0; m < columns; m++)
            {
                copySample[n][m] = sample[n][m][0]; // Copy of status vacancies.
            }
        }

        GenerRecomVo(Vl, 0.0, stepTime0, gammaSET, phiDrift);
        CalcCurrent(Vl, 0.0);

        Int_t accuracy;
        if (I > complIset)
        { // Amp
            achievCurrCompl = true;
            Double_t bestI = 10000.0 * complIset; // Amp
            Bool_t achieveToleranceI = false;

            for (accuracy = 1; accuracy <= 100; accuracy++)
            {

                for (Int_t n = 0; n < rows; n++)
                {
                    for (Int_t m = 0; m < columns; m++)
                    {
                        sample[n][m][0] = copySample[n][m]; // Copy of status vacancies.
                    }
                }

                stepTime = stepTime0 / TMath::Power(1.1, accuracy);

                GenerRecomVo(Vl, 0.0, stepTime, gammaSET, phiDrift); // This changes sample[][][0].
                CalcCurrent(Vl, 0.0);

                if ((I > complIset * 0.90) && (I < bestI))
                { // If I > 90%*currentCompliance and I < bestI
                    achieveToleranceI = true;
                    for (Int_t n = 0; n < rows; n++)
                    {
                        for (Int_t m = 0; m < columns; m++)
                        {
                            bestSample[n][m] = sample[n][m][0]; // Copy of status vacancies.
                        }
                    }
                    bestI = I;
                    // cout << accuracy << " " << I << "A " << stepTime << "s" << endl;
                }
            }
            if (achieveToleranceI)
            {
                for (Int_t n = 0; n < rows; n++)
                {
                    for (Int_t m = 0; m < columns; m++)
                    {
                        sample[n][m][0] = bestSample[n][m]; // Copy of status vacancies.
                    }
                }
                I = bestI;
            }
            else
            {
                for (Int_t n = 0; n < rows; n++)
                {
                    for (Int_t m = 0; m < columns; m++)
                    {
                        sample[n][m][0] = copySample[n][m]; // Copy of status vacancies.
                    }
                }
                I = complIset;
            }
        }
        JouleHeatOutDataOutVoCs(Vl);
    }
}

void MAIN_FRAME::ResetProcess(Double_t initVl, Double_t endVl, Double_t step)
{

    for (Double_t Vl = initVl; Vl >= endVl; Vl += step)
    {
        GenerRecomVo(Vl, 0.0, stepTime0, gammaRESET, phiDrift); //-> Ns
        CalcCurrent(Vl, 0.0); // -> I

        if (I > complIreset)
            I = complIreset; // Amp

        JouleHeatOutDataOutVoCs(Vl);
    }
}
void MAIN_FRAME::SweepProcess(Double_t initVl, Double_t endVl, Double_t step)
{
    if (step > 0)
    {
        for (Double_t Vl = initVl; Vl <= endVl; Vl += step)
        {
            GenerRecomVo(Vl, 0.0, stepTime0, gammaRESET, phiDrift);
            CalcCurrent(Vl, 0.0);
            if ((Vl < 0.0) && (I > complIreset))
                I = complIreset;
            JouleHeatOutDataOutVoCs(Vl);
        }
    }
    else if (step < 0)
    {
        for (Double_t Vl = initVl; Vl >= endVl; Vl += step)
        {
            GenerRecomVo(Vl, 0.0, stepTime0, gammaSET, phiDrift);
            CalcCurrent(Vl, 0.0);
            if ((Vl > 0.0) && (I > complIset))
                I = complIset;
            JouleHeatOutDataOutVoCs(Vl);
        }
    }
}
void MAIN_FRAME::Simulate()
{
    system("rmdir /s /q \"configurations\"");
    system("md \"configurations\"");
    simulateButton->SetEnabled(false);
    drawButton->SetEnabled(false); 
    ((TRootCanvas *)printCanvas->GetCanvasImp())->UnmapWindow(); // Hide printCanvas
    
    Init();

    outFile.open(outputTextEntry->GetText());

    outFile << "Structure layers: " << structureTextEntry->GetText() << endl;
    outFile << "Thickness: " << L << "cm" << endl;
    outFile << "Rows: " << rows << endl;
    outFile << "Columns: " << columns << endl;
    outFile << endl;
    outFile << "N_LRS: " << N_LRS << endl;
    outFile << "N_HRS: " << N_HRS << endl;
    outFile << "Nfresh: " << Nfresh << endl;
    outFile << "Vforming: " << Vforming << "V" << endl;
    outFile << "Vreset: " << Vreset << "V" << endl;
    outFile << "Vset: " << Vset << "V" << endl;
    outFile << "Khrs: " << Khrs << "a.u." << endl;
    outFile << "Klrs: " << Klrs << "a.u. cm3" << endl;
    outFile << endl;
    outFile << "gammaSET for generation probb.: " << gammaSET << endl;
    outFile << "gammaRESET for generation probb.: " << gammaRESET << endl;
    outFile << "phiDrift oxygen migrat: " << phiDrift << endl;
    outFile << "I compliance FORMING: " << complIforming << "A" << endl;
    outFile << "I compliance RESET: " << complIreset << "A" << endl;
    outFile << "I compliance SET: " << complIset << "A" << endl;
    outFile << "a const. lattice: " << a << "cm" << endl;
    outFile << "A Area device: " << A << "cm2" << endl;
    outFile << endl;
    outFile << "Vo_ini Num initial Vos: " << numVoIni << endl;
    outFile << "t_0 gener-recomb: " << stepTime0 << "s" << endl;
    outFile << "E_Oe oxygen equilib.: " << Eoe << "eV" << endl;
    outFile << "E_Om oxygen migrat.: " << Eom << "eV" << endl;
    outFile << "L_O decaying oxig. ion: " << Lo << "a" << endl;
    outFile << "beta0 recomb. factor: " << beta0 << endl;
    outFile << "Rth thermal resistance: " << Rth << "K/W" << endl;
    outFile << "Ao atten. electron wave: " << Ao << "cm" << endl;
    outFile << endl;
    outFile << "Nc: " << Nc << "/cm3" << endl;
    outFile << "u: " << u << "cm2/(V s)" << endl;
    outFile << "perm Relative dielect. const.: " << epsilon << endl;
    outFile << "phi_t (Eg - trapVo) into Eg: " << phit << "V" << endl;
    outFile << endl;

    outFile << "V (V)\tNs (a.u.)\tI (A)\tT (K)\tsumVos w/o ncs\tsumVos with ncs\tF_H (V/cm)\tv (cm/s)\tt (s)\tv*t (*a)\tIpf (A)\tIsclc (A)\tIpf*Khrs (A)\tIsclc*Klrs (A)\tFhrs\tFlrs\tIhrs (A)\tIlrs (A)\tnum procs" << endl;

    Forming(0.0, Vforming, 0.1);
    SweepProcess(Vforming, 0.0, -0.1);
    ResetProcess(0.0, Vreset, -0.1);
    SweepProcess(Vreset, 0.0, 0.1);
    for (int n = 1; n < (cycles + 0.1); n++)
    { // cycles is a double <- double necesary for CONTROLS_VALUE.

        numProcess = n;
        SetProcess(0.0, Vset, 0.1);
        SweepProcess(Vset, 0.0, -0.1);
        ResetProcess(0.0, Vreset, -0.1);
        SweepProcess(Vreset, 0.0, 0.1);
    }
    outFile.close();

    openApp = false;
    DrawData();

    simulateButton->SetEnabled(true);
    drawButton->SetEnabled(true);
}
void MAIN_FRAME::DrawLastSimulation() {
    system("rmdir /s /q \"VocCONFIGURATIONS\"");
    system("md \"VocCONFIGURATIONS\"");
    
    simulateButton->SetEnabled(false);
    drawButton->SetEnabled(false);
    printCanvas->SetEditable(kTRUE);

    Int_t cols, rws;

    Char_t arrChar[1000];
    
    TSystemDirectory dir("./configurations", "./configurations");
    TList *files = dir.GetListOfFiles();
    
    if (files) { // If is there files
        TSystemFile *file;
        TString fname;
        TIter next(files);
        while ((file = (TSystemFile *)next()))
        {
            fname = file->GetName();

            if(!file->IsDirectory() && fname.BeginsWith("00000001")) { //Obtain number of rows and columns from first VoConfigurations. 
                nameMatrix = "configurations/";
                nameMatrix += fname;
                ifstream inputLayers(nameMatrix);

                rws = 0;
                while (!inputLayers.eof())
                {
                    inputLayers.getline(arrChar, 1000);
                    if (arrChar[0] == '\0')
                        continue;
                    for (Int_t n = 0; n < 1000; n++)
                    {
                        if (arrChar[n] == '\0')
                        {
                            cols = n;
                            rws++;
                            break;
                        }
                    }
                }
                inputLayers.close(); 
                printCanvas->SetWindowSize(250 * ( cols/rws), 250);
                printCanvas->Clear();
                printCanvas->Show(); 
            }

            if (!file->IsDirectory() && fname.EndsWith(".txt"))
            {
                nameMatrix = "configurations/";
                nameMatrix += fname;
                ifstream inputLayers(nameMatrix);

                nameMatrix = "vacancies ";
                nameMatrix += fname(0, 8);   // Different name for avoid warnings
                TH2F *hystogram2D = new TH2F(nameMatrix, "Title", cols + 2, -1, cols + 1, rws, 0, rws); // (cols+1)-(-1)=cols+2, rws-(0) = rws.

                nameMatrix = fname(9, fname.Sizeof() - 14);
                hystogram2D->SetTitle(nameMatrix);
                Bool_t fullBrkdDiel = true;

                Int_t y = 0;

                while (!inputLayers.eof())
                {
                    hystogram2D->Fill(-1.0, y, 1.5);
                    hystogram2D->Fill(cols, y, 1.5); 

                    inputLayers.getline(arrChar, 1000);
                    if (arrChar[0] == '\0')
                        continue;
                    for (Int_t x = 0; x < 1000; x++)
                    {
                        if (arrChar[x] == '\0')
                            break;
                        else
                        {
                            if (arrChar[x] == '2')
                            {
                                hystogram2D->Fill(x, y, 0.5); // If it is a fixed vacancie.
                            }
                            else {
                                TString charNumb = arrChar[x];
                                hystogram2D->Fill(x, y, charNumb.Atof()); // else it is a 1.0->Vo or 0.0->W/o Vo.
                                if (arrChar[x] == '0')
                                    fullBrkdDiel = false;
                            }
                        }
                    }
                    y++;
                }
                inputLayers.close();

                if (fullBrkdDiel)
                    hystogram2D->Fill(-1.0, 0.0, -1.5); // Avoid the change of range colour when every device is Vo.

                nameMatrix = "VocCONFIGURATIONS/";
                nameMatrix += fname(0, fname.Sizeof() - 5); // Remove the extension ".txt".
                nameMatrix += ".gif";

                printCanvas->cd();
                hystogram2D->SetLabelSize(0.08, "x");
                hystogram2D->SetLabelSize(0.08, "y");
                hystogram2D->Draw("col grid");
                printCanvas->Print(nameMatrix);
            }
        }
    }
    simulateButton->SetEnabled(true);
    drawButton->SetEnabled(true);
    printCanvas->SetEditable(false);
}
/**********************CONTROLS_SCIENTIFIC methods*********************/
CONTROLS_SCIENTIFIC::CONTROLS_SCIENTIFIC(TGFrame *father, TString name, TString units, Double_t &value1) : TGVerticalFrame(father)
{

    value = &value1;

    if (*value == 0.0)
    {
        fac = 0.0;
        minFac = 0.0;
        maxFac = 10.0;
        exp = 0;
        minExp = -5;
        maxExp = 5;
    }
    else
    {

        Double_t log10 = TMath::Log10(TMath::Abs(*value));

        if (log10 < 0.0)
            exp = log10 - 1.0;
        else
            exp = log10;

        if (*value < 0.0)
        {
            minFac = -10.0;
            maxFac = 0.0;
        }
        else
        {
            minFac = 0.0;
            maxFac = 10.0;
        }
        fac = *value / TMath::Power(10.0, exp);

        maxExp = exp + 5;
        minExp = exp - 5;
    }

    this->name = name;
    this->units = units;

    TGLayoutHints *expandHints = new TGLayoutHints(kLHintsExpandX | kLHintsExpandY, 1, 1, 1, 1);
    TGLayoutHints *topHints = new TGLayoutHints(kLHintsExpandX | kLHintsTop, 1, 1, 1, 1);
    TGLayoutHints *centerHints = new TGLayoutHints(kLHintsExpandX | kLHintsCenterY, 1, 1, 1, 1);
    TGLayoutHints *bottomHints = new TGLayoutHints(kLHintsExpandX | kLHintsBottom, 1, 1, 1, 1);

    //     fmtStr << "This number is " << fixed << setprecision(1) << a << ".\n";
    //     string line = fmtStr.str();
    //     cout << line;

    TString text = name + "=";
    ostringstream oString;
    oString << setprecision(3) << (*value);
    text += oString.str();
    text += units;
    valueLabel = new TGLabel(this, text);
    AddFrame(valueLabel, topHints);

    TGHorizontalFrame *tghf2 = new TGHorizontalFrame(this);
    AddFrame(tghf2, expandHints);

    TGVerticalFrame *tgvfFac = new TGVerticalFrame(tghf2);
    tghf2->AddFrame(tgvfFac, expandHints);

    maxFacNumberEntry = new TGNumberEntry(tgvfFac);
    tgvfFac->AddFrame(maxFacNumberEntry, topHints);
    maxFacNumberEntry->SetNumber(maxFac);
    (maxFacNumberEntry->GetNumberEntry())->Connect("TextChanged(char*)", "CONTROLS_SCIENTIFIC", this, "DoMaxFac()");

    facNumberEntry = new TGNumberEntry(tgvfFac);
    tgvfFac->AddFrame(facNumberEntry, centerHints);
    facNumberEntry->SetNumber(fac);
    (facNumberEntry->GetNumberEntry())->Connect("TextChanged(char*)", "CONTROLS_SCIENTIFIC", this, "DoFac()");

    minFacNumberEntry = new TGNumberEntry(tgvfFac);
    tgvfFac->AddFrame(minFacNumberEntry, bottomHints);
    minFacNumberEntry->SetNumber(minFac);
    (minFacNumberEntry->GetNumberEntry())->Connect("TextChanged(char*)", "CONTROLS_SCIENTIFIC", this, "DoMinFac()");

    facSlider = new TGVSlider(tghf2, 150, kSlider1);
    tghf2->AddFrame(facSlider, expandHints);
    facSlider->SetRange(-100, 0);
    facSlider->SetPosition(-((fac - minFac) * 100.0 / (maxFac - minFac)));
    //	facSlider->Connect("Released()", "MAIN_FRAME", this, "SolveLightDrawSolution()");
    facSlider->Connect("PositionChanged(Int_t)", "CONTROLS_SCIENTIFIC", this, "MoveFacSlider(Int_t)");

    TGVerticalFrame *tgvfExp = new TGVerticalFrame(tghf2);
    tghf2->AddFrame(tgvfExp, expandHints);

    maxExpNumberEntry = new TGNumberEntry(tgvfExp);
    maxExpNumberEntry->SetNumStyle(TGNumberFormat::kNESInteger);
    tgvfExp->AddFrame(maxExpNumberEntry, topHints);
    maxExpNumberEntry->SetNumber(maxExp);
    (maxExpNumberEntry->GetNumberEntry())->Connect("TextChanged(char*)", "CONTROLS_SCIENTIFIC", this, "DoMaxExp()");

    expNumberEntry = new TGNumberEntry(tgvfExp);
    expNumberEntry->SetNumStyle(TGNumberFormat::kNESInteger);
    tgvfExp->AddFrame(expNumberEntry, centerHints);
    expNumberEntry->SetNumber(exp);
    (expNumberEntry->GetNumberEntry())->Connect("TextChanged(char*)", "CONTROLS_SCIENTIFIC", this, "DoExp()");

    minExpNumberEntry = new TGNumberEntry(tgvfExp);
    minExpNumberEntry->SetNumStyle(TGNumberFormat::kNESInteger);
    tgvfExp->AddFrame(minExpNumberEntry, bottomHints);
    minExpNumberEntry->SetNumber(minExp);
    (minExpNumberEntry->GetNumberEntry())->Connect("TextChanged(char*)", "CONTROLS_SCIENTIFIC", this, "DoMinExp()");

    expSlider = new TGVSlider(tghf2, 150, kSlider1);
    tghf2->AddFrame(expSlider, expandHints);
    expSlider->SetRange(-100, 0);
    expSlider->SetPosition(-((exp - minExp) * 100.0 / (maxExp - minExp)));
    //	expSlider->Connect("Released()", "MAIN_FRAME", this, "SolveLightDrawSolution()");
    expSlider->Connect("PositionChanged(Int_t)", "CONTROLS_SCIENTIFIC", this, "MoveExpSlider(Int_t)");

    ChangeOptions(/*kRaisedFrame |*/ kSunkenFrame);
}
void CONTROLS_SCIENTIFIC::DoMaxFac()
{
    if (maxFacNumberEntry->GetNumber() >= fac)
    {
        maxFac = maxFacNumberEntry->GetNumber();
    }
    else
    {
        maxFac = fac;
        maxFacNumberEntry->SetNumber(fac);
    }
    // Change position of slider
    facSlider->SetPosition(-((fac - minFac) * 100.0 / (maxFac - minFac)));
}
void CONTROLS_SCIENTIFIC::DoFac()
{
    if ((minFac <= facNumberEntry->GetNumber()) && (facNumberEntry->GetNumber() <= maxFac))
    {
        fac = facNumberEntry->GetNumber();
    }
    else if (minFac > facNumberEntry->GetNumber())
    {
        fac = minFac;
        facNumberEntry->SetNumber(minFac);
    }
    else if (facNumberEntry->GetNumber() > maxFac)
    {
        fac = maxFac;
        facNumberEntry->SetNumber(maxFac);
    }
    //*exp = expNumberEntry->GetNumber(); //Actually value of exp is double. I do not konw why...
    *value = fac * TMath::Power(10.0, exp);
    TString text = name + "=";
    ostringstream oString;
    oString << setprecision(3) << (*value);
    text += oString.str();
    text += units;
    valueLabel->SetText(text);
    // Change position of slider
    facSlider->SetPosition(-((fac - minFac) * 100.0 / (maxFac - minFac)));
}
void CONTROLS_SCIENTIFIC::MoveFacSlider(Int_t param)
{
    fac = (-1.0 * param / 100.0) * (maxFac - minFac) + minFac;
    facNumberEntry->SetNumber(fac); // Change of NumberEntry call to TextChanged.
    //*value = fac*TMath::Power(10.0, exp);
    // TString text = name + "="; text += *value; text += units;
    // valueLabel->SetText(text);
    //	cout << *value << endl;
}
void CONTROLS_SCIENTIFIC::DoMinFac()
{
    if (minFacNumberEntry->GetNumber() <= fac)
    {
        minFac = minFacNumberEntry->GetNumber();
    }
    else
    {
        minFac = fac;
        minFacNumberEntry->SetNumber(fac);
    }
    // Change position of slider
    facSlider->SetPosition(-((fac - minFac) * 100.0 / (maxFac - minFac)));
}
void CONTROLS_SCIENTIFIC::DoMaxExp()
{
    if (maxExpNumberEntry->GetNumber() >= exp)
    {
        maxExp = maxExpNumberEntry->GetNumber();
    }
    else
    {
        maxExp = exp;
        maxExpNumberEntry->SetNumber(exp);
    }
    // Change position of slider
    expSlider->SetPosition(-((exp - minExp) * 100.0 / (maxExp - minExp)));
}
void CONTROLS_SCIENTIFIC::DoExp()
{
    if ((minExp <= expNumberEntry->GetNumber()) && (expNumberEntry->GetNumber() <= maxExp))
    {
        exp = expNumberEntry->GetNumber();
    }
    else if (minExp > expNumberEntry->GetNumber())
    {

        exp = minExp;
        expNumberEntry->SetNumber(minExp);
    }
    else if (expNumberEntry->GetNumber() > maxExp)
    {
        exp = maxExp;
        expNumberEntry->SetNumber(maxExp);
    }
    *value = fac * TMath::Power(10.0, exp);
    TString text = name + "=";
    ostringstream oString;
    oString << setprecision(3) << (*value);
    text += oString.str();
    text += units;
    valueLabel->SetText(text);
    // Change position of slider
    expSlider->SetPosition(-((exp - minExp) * 100.0 / (maxExp - minExp)));
}
void CONTROLS_SCIENTIFIC::MoveExpSlider(Int_t param)
{
    exp = (-1.0 * param / 100.0) * (maxExp - minExp) + minExp;
    expNumberEntry->SetNumber(exp);

    // 	*value = fac*TMath::Power(10.0, exp);
    // 	TString text = name + "="; text += *value; text += units;
    // 	valueLabel->SetText(text);
    //	cout << *value << endl;
}
void CONTROLS_SCIENTIFIC::DoMinExp()
{
    if (minExpNumberEntry->GetNumber() <= exp)
    {
        minExp = minExpNumberEntry->GetNumber();
    }
    else
    {
        minExp = exp;
        minExpNumberEntry->SetNumber(exp);
    }
    // Change position of slider
    expSlider->SetPosition(-((exp - minExp) * 100.0 / (maxExp - minExp)));
}
/**********************CONTROLS_VALUE methods*********************/
CONTROLS_VALUE::CONTROLS_VALUE(TGFrame *father, TString name, TString units, Double_t &value1) : TGVerticalFrame(father)
{

    this->value = &value1;
    this->max = MaxDoubleValue(*value);
    this->min = MinDoubleValue(*value);
    this->name = name;
    this->units = units;

    TGLayoutHints *expandHints = new TGLayoutHints(kLHintsExpandX | kLHintsExpandY, 1, 1, 1, 1);
    TGLayoutHints *topHints = new TGLayoutHints(kLHintsExpandX | kLHintsTop, 1, 1, 1, 1);
    TGLayoutHints *centerHints = new TGLayoutHints(kLHintsExpandX | kLHintsCenterY, 1, 1, 1, 1);
    TGLayoutHints *bottomHints = new TGLayoutHints(kLHintsExpandX | kLHintsBottom, 1, 1, 1, 1);

    TString text = name + "=";
    ostringstream oString;
    oString << setprecision(3) << (*value);
    text += oString.str();
    text += units;
    valueLabel = new TGLabel(this, text);
    AddFrame(valueLabel, topHints);

    TGHorizontalFrame *tghf2 = new TGHorizontalFrame(this);
    AddFrame(tghf2, expandHints);

    TGVerticalFrame *tgvfValue = new TGVerticalFrame(tghf2);
    tghf2->AddFrame(tgvfValue, expandHints);

    maxNumberEntry = new TGNumberEntry(tgvfValue);
    tgvfValue->AddFrame(maxNumberEntry, topHints);
    maxNumberEntry->SetNumber(max);
    (maxNumberEntry->GetNumberEntry())->Connect("TextChanged(char*)", "CONTROLS_VALUE", this, "DoMax()");

    valueNumberEntry = new TGNumberEntry(tgvfValue);
    tgvfValue->AddFrame(valueNumberEntry, centerHints);
    valueNumberEntry->SetNumber(*value);
    (valueNumberEntry->GetNumberEntry())->Connect("TextChanged(char*)", "CONTROLS_VALUE", this, "DoValue()");

    minNumberEntry = new TGNumberEntry(tgvfValue);
    tgvfValue->AddFrame(minNumberEntry, bottomHints);
    minNumberEntry->SetNumber(min);
    (minNumberEntry->GetNumberEntry())->Connect("TextChanged(char*)", "CONTROLS_VALUE", this, "DoMin()");

    valueSlider = new TGVSlider(tghf2, 150, kSlider1);
    tghf2->AddFrame(valueSlider, expandHints);
    valueSlider->SetRange(-100, 0);
    valueSlider->SetPosition(-((*value - min) * 100.0 / (max - min)));
    //	valueSlider->Connect("Released()", "MAIN_FRAME", this, "SolveLightDrawSolution()");
    valueSlider->Connect("PositionChanged(Int_t)", "CONTROLS_VALUE", this, "MoveSlider(Int_t)");

    ChangeOptions(/*kRaisedFrame |*/ kSunkenFrame);
}
Double_t CONTROLS_VALUE::MinDoubleValue(Double_t doubleValue)
{
    if (doubleValue == 0.0)
        return -1.0;
    if (doubleValue > 0.0)
        return 0.0;

    // if(doubleValue < 0.0)

    doubleValue *= -1.0; // Absolute value.

    Double_t log10 = TMath::Log10(doubleValue);

    Int_t exp10;
    if (log10 < 0.0)
        exp10 = log10;
    else
        exp10 = log10 + 1.0;
    Double_t minVal = -TMath::Power(10.0, exp10);

    if (doubleValue < minVal)
        return -doubleValue * 10.0;

    return minVal;
}
Double_t CONTROLS_VALUE::MaxDoubleValue(Double_t doubleValue)
{
    if (doubleValue == 0.0)
        return 1.0;
    if (doubleValue < 0.0)
        return 0.0;

    // if(doubleValue > 0.0)

    Double_t log10 = TMath::Log10(doubleValue);

    Int_t exp10;
    if (log10 < 0.0)
        exp10 = log10;
    else
        exp10 = log10 + 1.0;
    Double_t maxVal = TMath::Power(10.0, exp10);

    if (doubleValue > maxVal)
        return doubleValue * 10.0;

    return maxVal;
}
void CONTROLS_VALUE::DoMax()
{
    if (maxNumberEntry->GetNumber() >= *value)
    {
        max = maxNumberEntry->GetNumber();
    }
    else
    {
        max = *value;
        maxNumberEntry->SetNumber(*value);
    }
    // Change position of slider
    valueSlider->SetPosition(-((*value - min) * 100.0 / (max - min)));
}
void CONTROLS_VALUE::DoValue()
{
    if ((min <= valueNumberEntry->GetNumber()) && (valueNumberEntry->GetNumber() <= max))
    {
        *value = valueNumberEntry->GetNumber();
    }
    else if (min > valueNumberEntry->GetNumber())
    {
        *value = min;
        valueNumberEntry->SetNumber(min);
    }
    else if (valueNumberEntry->GetNumber() > max)
    {
        *value = max;
        valueNumberEntry->SetNumber(max);
    }

    TString text = name + "=";
    ostringstream oString;
    oString << setprecision(3) << (*value);
    text += oString.str();
    text += units;
    valueLabel->SetText(text);
    // Change position of slider
    valueSlider->SetPosition(-((*value - min) * 100.0 / (max - min)));
}
void CONTROLS_VALUE::MoveSlider(Int_t param)
{
    *value = (-1.0 * param / 100.0) * (max - min) + min;
    valueNumberEntry->SetNumber(*value);

    // 	TString text = name + "="; text += *value; text += units;
    // 	valueLabel->SetText(text);
    //	cout << *value << endl;
}
void CONTROLS_VALUE::DoMin()
{
    if (minNumberEntry->GetNumber() <= *value)
    {
        min = minNumberEntry->GetNumber();
    }
    else
    {
        min = *value;
        minNumberEntry->SetNumber(*value);
    }
    // Change position of slider
    valueSlider->SetPosition(-((*value - min) * 100.0 / (max - min)));
}
/*************************Close application********************/
void MAIN_FRAME::CloseWindow()
{
    gApplication->Terminate(0);
}
